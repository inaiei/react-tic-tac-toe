const PlayMode: Enumerator = {
  onePlayer: 'onePlayer',
  twoPlayers: 'twoPlayers',
};

const initialState = {
  board: [[null, null, null], [null, null, null], [null, null, null]],
  player1: 'X',
  player2: 'O',
  currentPlayer: 'X',
  gameResult: null,
  playMode: null,
};

const gameReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'START_GAME':
      return {
        ...state,
        board: [[null, null, null], [null, null, null], [null, null, null]],
        currentPlayer: state.player1,
        playMode: PlayMode.onePlayer,
        gameResult: null,
      };
    case 'UPDATE_BOARD': {
      const gameBoard = JSON.parse(JSON.stringify(state.board));

      const getResult = (type, values, index) => {
        return /(.)\1\1/.exec(values.join(''))
          ? {
              type: type,
              index: index,
              winner:
                values[0].indexOf(state.player1) === 0
                  ? state.player1
                  : state.player2,
            }
          : null;
      };

      let result = gameBoard
        .map((row, index) => getResult('Row', row, index))
        .concat(
          [0, 1, 2].map((col, index) =>
            getResult('Col', gameBoard.map(row => row[col]), index)
          )
        )
        .concat(
          getResult('Diagonal1', gameBoard.map((a, index) => a[index]), 0)
        ) 
        .concat(
          getResult(
            'Diagonal2',
            gameBoard.reverse().map((a, index) => a[index]),
            1
          )
        ) 
        .filter(item => item != null);

      let gameResult = null;
      if (result.length) {
        gameResult = result[0];
      }

      return {
        ...state,
        board: state.board,
        gameResult: gameResult,
      };
    }
    case 'SWITCH_PLAYER':
      return {
        ...state,
        currentPlayer:
          state.currentPlayer === state.player1 ? state.player2 : state.player1,
      };
    default:
      return state;
  }
};

export default gameReducer;
