import React, { Component } from 'react';
import {
  View,
  Image,
  StyleSheet,
  TouchableWithoutFeedback,
} from 'react-native';
import { connect } from 'react-redux';
import RNShake from 'react-native-shake';

import Container from './Container';

class BoardFrame extends Component {
  componentWillMount() {
    RNShake.addEventListener('ShakeEvent', () => {
      this.props.dispatch({
        type: 'START_GAME',
      });
    });
  }

  componentWillUnmount() {
    RNShake.removeEventListener('ShakeEvent');
  }

  createFrame = () => {
    return this.props.game.board.map((row, rowIndex) => {
      return (
        <View style={styles.row} key={rowIndex}>
          {row.map((col, colIndex) => {
            return <Container row={rowIndex} column={colIndex} />;
          })}
        </View>
      );
    });
  };

  render() {
    return (
      <View style={styles.container}>
        <View
          style={[
            styles.gameBoard,
            this.props.game.gameResult != null ? styles.gameOver : styles.gameOn,
          ]}>
          {this.createFrame()}
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    game: state,
  };
};

export default connect(mapStateToProps)(BoardFrame);

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20
  },
  gameBoard: {
    width: 320,
    height: 320,
  },
  gameOver: {
    backgroundColor: '#eee',
  },
  row: {
    flex: 1,
    flexDirection: 'row',
  },
});
