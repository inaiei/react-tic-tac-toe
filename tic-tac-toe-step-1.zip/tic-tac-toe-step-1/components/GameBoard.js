import React, { Component } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';

import Header from './Header';
import BoardFrame from './BoardFrame';
import GameInfo from './GameInfo';

export default class GameBoard extends Component {
  static navigationOptions = {
    title: 'Lets Play',
  };

  render() {
    return (
      <View style={styles.container}>
        <ScrollView>
          <Header />
          <BoardFrame style={styles.boardFrame} />
          <GameInfo />
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  boardFrame: {
    flex: 1,
  },
});
