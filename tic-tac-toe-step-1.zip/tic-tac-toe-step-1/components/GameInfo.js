import React, { Component } from 'react';
import { StyleSheet, Text, Button, View } from 'react-native';
import { connect } from 'react-redux';

class GameInfo extends Component {
  onRestart = () => {
    this.props.dispatch({
      type: 'START_GAME',
    });
  };

  render() {
    if (this.props.game.gameResult == null) {
      return null;
    }

    return (
      <View style={styles.container}>
        <Text style={styles.title}>The winner is {this.props.game.gameResult.winner}</Text>

        <Button
          onPress={this.onRestart}
          title="Restart"
          color="#841584"
          accessibilityLabel="Play again"
        />
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    game: state,
  };
};

export default connect(mapStateToProps)(GameInfo);

const styles = StyleSheet.create({
  container: {
    marginTop: 20,
    backgroundColor: 'skyblue',
    flexDirection: 'row',
  },
  title: {
    color: '#fff',
    fontWeight: 'bold',
    flex: 1,
    fontSize: 23,
    textAlign: 'center',
    margin: 10,
  },
});
