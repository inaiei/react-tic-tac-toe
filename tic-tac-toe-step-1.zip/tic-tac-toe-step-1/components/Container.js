import React, { Component } from 'react';
import {
  View,
  Image,
  StyleSheet,
  TouchableWithoutFeedback,
} from 'react-native';
import { connect } from 'react-redux';

class Container extends Component {
  getContainerStyle = () => {
    const gameResult = this.props.game.gameResult;

    if (gameResult != null) {
      if (
        (gameResult.type === 'Row' && this.props.row === gameResult.index) ||
        (gameResult.type === 'Col' && this.props.column === gameResult.index) ||
        (gameResult.type === 'Diagonal1' &&
          this.props.row === this.props.column) ||
        (gameResult.type === 'Diagonal2' &&
          (this.props.row + this.props.column) === 2)
      ) {
        return styles.winner;
      }
    }
  };

  getImage = () => {
    const token = this.props.game.board[this.props.row][this.props.column];

    if (token === 'X') {
      return (
        <Image style={styles.images} source={require('Assets/cross.png')} />
      );
    } else if (token === 'O') {
      return (
        <Image style={styles.images} source={require('Assets/circle.png')} />
      );
    }
    return;
  };

  boardClickHandler(row: number, column: number) {
    if (this.props.game.gameResult != null) {
      return;
    }

    let board = this.props.game.board;

    if (board[row][column] == null) {
      board[row][column] = this.props.game.currentPlayer;

      this.props.dispatch({
        type: 'UPDATE_BOARD',
        board,
      });

      this.props.dispatch({ type: 'SWITCH_PLAYER' });
    }
  }

  render() {
    return (
      <TouchableWithoutFeedback
        onPress={() =>
          this.boardClickHandler(this.props.row, this.props.column)
        }>
        <View style={[styles.box, this.getContainerStyle()]}>
          {this.getImage()}
        </View>
      </TouchableWithoutFeedback>
    );
  }
}

const mapStateToProps = state => {
  return {
    game: state,
  };
};

export default connect(mapStateToProps)(Container);

const styles = StyleSheet.create({
  box: {
    width: '33%',
    justifyContent: 'center',
    borderWidth: 2,
    padding: 5,
  },
  images: {
    width: '100%',
    height: '100%',
  },
  winner: {
    backgroundColor: '#CEF6CE',
  },
});
