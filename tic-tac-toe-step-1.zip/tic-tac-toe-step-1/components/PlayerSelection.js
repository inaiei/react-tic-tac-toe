import React, { Component } from 'react';
import { StyleSheet, Button, View } from 'react-native';
import { connect } from 'react-redux';

class PlayerSelection extends Component {
  static navigationOptions = {
    title: 'Player Selection',
  };

  onePlayer = () => {
    this.props.dispatch({
      type: 'START_GAME',
    });

    this.props.navigation.navigate('GameBoard');
  };

  twoPlayers = () => {
    this.props.dispatch({
      type: 'START_GAME_TWO_PLAYERS',
    });

    //this.props.navigation.navigate("GameBoard");
  };

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.buttonContainer}>
          <Button
            style={styles.button}
            onPress={this.onePlayer}
            title="One Player"
            accessibilityLabel="One Player"
          />
        </View>
        <View style={styles.buttonContainer}>
          <Button
            style={styles.button}
            onPress={this.twoPlayers}
            title="Two Players"
            accessibilityLabel="Two Players"
          />
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    game: state,
  };
};

export default connect(mapStateToProps)(PlayerSelection);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonContainer: {
    flexDirection: 'column',
    margin: 20,
    width: '85%',
  },
  button: {},
});
